# SlitterPy
A Simple Testing Framework
